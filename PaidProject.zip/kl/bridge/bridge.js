document.addEventListener('SyncBotCredentials', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_CREDENTIALS', 
        url: e.detail.url, 
        key: e.detail.key,
        userId: e.detail.userId
    });
});

document.addEventListener('SyncWalletCards', (e) => {
    chrome.runtime.sendMessage({ action: 'UPDATE_WALLET', cards: e.detail.cards });
});

// Catches the OTP from the Dashboard and sends it to the Background Worker
document.addEventListener('InjectAmazonOTP', (e) => {
    chrome.runtime.sendMessage({ action: 'FORWARD_OTP_TO_AMAZON', otp: e.detail.otp });
});
// Relays the Refund command to the Background script
document.addEventListener('TriggerAmazonRefund', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_REFUND_BOT', 
        amazonOrderId: e.detail.amazonOrderId 
    });
});
// Relays Payment Vault cards to the extension memory
document.addEventListener('SyncWalletCards', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_WALLET', 
        cards: e.detail.cards 
    });
});
// NEW: Captures the "Checkout All" command from the dashboard
document.addEventListener('TriggerBatchCheckout', () => {
    chrome.runtime.sendMessage({ action: 'EXECUTE_BATCH_CHECKOUT' });
});