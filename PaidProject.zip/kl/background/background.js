const CONFIG = {
    URL: 'https://fsqdpnoygftookrcukdi.supabase.co',
    KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzcWRwbm95Z2Z0b29rcmN1a2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyMDY3MDYsImV4cCI6MjEwMzc4MjcwNn0.GpFEqhJ76N6KC5FDW4IaaZdJLcuCMkx5b787ptscUiU',
    USER_ID: null 
};


let isProcessing = false;
let activeTabId = null;

setInterval(pollCartQueue, 3000);
pollCartQueue();

async function pollCartQueue() {
    if (isProcessing) return;

    try {
        // Bulletproof Fallback: If USER_ID is missing, just grab the next pending order anyway
        let endpoint = `${CONFIG.URL}/rest/v1/bulk_orders?status=eq.pending&limit=1`;
        if (CONFIG.USER_ID) {
            endpoint += `&user_id=eq.${encodeURIComponent(CONFIG.USER_ID)}`;
        }
        
        const res = await fetch(endpoint, {
            headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}` }
        });
        const orders = await res.json();

        if (orders && orders.length > 0) {
            isProcessing = true;
            const order = orders[0];
            
            await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${order.id}`, {
                method: 'PATCH',
                headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'running' })
            });

            await chrome.storage.local.set({ 
                currentOrderId: order.id, 
                orderQuantity: order.quantity || 1,
                couponCode: order.coupon_code || '',
                targetName: order.asin
            });

// ... [Top of file remains the same] ...

            // --- THE 3-WAY SMART ROUTER ---
            const cleanIdentifier = order.asin ? order.asin.trim() : '';
            const isAsin = /^[A-Z0-9]{10}$/i.test(cleanIdentifier);
            const isUrl = cleanIdentifier.startsWith('http');
            
            let targetUrl = '';
            
            if (isUrl) {
                targetUrl = cleanIdentifier; // 1. Direct URL: Go straight to the link
            } else if (isAsin) {
                targetUrl = `https://www.amazon.in/dp/${cleanIdentifier}`; // 2. ASIN: Go to product page
            } else {
                targetUrl = `https://www.amazon.in/s?k=${encodeURIComponent(cleanIdentifier)}`; // 3. Name: Go to Search
            }

            // Route to the single active tab
            if (activeTabId) {
                chrome.tabs.update(activeTabId, { url: targetUrl, active: true }).catch(async () => {
                    const newTab = await chrome.tabs.create({ url: targetUrl, active: true });
                    activeTabId = newTab.id;
                });
            } else {
                const newTab = await chrome.tabs.create({ url: targetUrl, active: true });
                activeTabId = newTab.id;
            }

            setTimeout(() => { isProcessing = false; }, 15000);
        }
    } catch (e) {
        console.error("Bot Error:", e);
        isProcessing = false;
    }
}

// ... [Rest of the file remains the same] ...

chrome.runtime.onMessage.addListener((message) => {
    // Routes the OTP to the active Amazon page
    if (message.action === 'FORWARD_OTP_TO_AMAZON') {
        if (activeTabId) {
            chrome.tabs.sendMessage(activeTabId, { action: 'PHYSICALLY_TYPE_OTP', otp: message.otp });
        }
    }// Triggers the Refund/Cancel Bot
    if (message.action === 'EXECUTE_REFUND_BOT') {
        isProcessing = true; 
        const orderUrl = `https://www.amazon.in/gp/your-account/order-details?orderID=${message.amazonOrderId}`;
        
        if (activeTabId) {
            chrome.tabs.update(activeTabId, { url: orderUrl, active: true }).catch(() => {
                chrome.tabs.create({ url: orderUrl, active: true }, (t) => activeTabId = t.id);
            });
        } else {
            chrome.tabs.create({ url: orderUrl, active: true }, (t) => activeTabId = t.id);
        }
    }
    // Trigger Tracking Scraper
    if (message.action === 'EXECUTE_TRACKING_BOT') {
        isProcessing = true; 
        
        // Save the database ID so we know which row to update when the data comes back
        chrome.storage.local.set({ activeTrackingDbId: message.dbOrderId });
        
        // Navigate directly to Amazon's internal progress tracker page
        const trackingUrl = `https://www.amazon.in/progress-tracker/package/?orderId=${message.amazonOrderId}`;
        
        if (activeTabId) {
            chrome.tabs.update(activeTabId, { url: trackingUrl, active: true }).catch(() => {
                chrome.tabs.create({ url: trackingUrl, active: true }, (t) => activeTabId = t.id);
            });
        } else {
            chrome.tabs.create({ url: trackingUrl, active: true }, (t) => activeTabId = t.id);
        }
    }

    // Save Scraped Data to Supabase
    if (message.action === 'TRACKING_SCRAPED') {
        chrome.storage.local.get(['activeTrackingDbId'], async (data) => {
            if (data.activeTrackingDbId) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.activeTrackingDbId}`, {
                    method: 'PATCH',
                    headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        tracking_id: message.tracking_id,
                        courier: message.courier,
                        tracking_status: message.tracking_status
                    })
                });
            }
            isProcessing = false;
        });
    }
    if (message.action === 'ITEM_CARTED') {
        chrome.storage.local.get(['currentOrderId'], async (data) => {
            if (data.currentOrderId) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.currentOrderId}`, {
                    method: 'PATCH',
                    headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        status: 'completed',
                        taxable_value: message.taxable_value || 0,
                        gst_amount: message.gst_amount || 0
                    })
                });
            }
        });
        isProcessing = false; 
    }
    
    if (message.action === 'EXECUTE_BATCH_CHECKOUT') {
        isProcessing = true; 
        if (activeTabId) {
            chrome.tabs.update(activeTabId, { url: 'https://www.amazon.in/cart', active: true }).catch(() => {
                chrome.tabs.create({ url: 'https://www.amazon.in/cart', active: true });
            });
        } else {
            chrome.tabs.create({ url: 'https://www.amazon.in/cart', active: true }, (t) => activeTabId = t.id);
        }
    }

    if (message.action === 'UPDATE_CREDENTIALS') {
        CONFIG.URL = message.url; 
        CONFIG.KEY = message.key;
        CONFIG.USER_ID = message.userId; 
    }

    if (message.action === 'UPDATE_WALLET') {
        chrome.storage.local.set({ walletCards: message.cards });
    }
});