async function runCheckoutEngine() {
    const url = window.location.href;

    // Step 1: Cart Page -> Proceed to Buy
    if (url.includes('/cart')) {
        const proceedBtn = document.querySelector('input[name="proceedToRetailCheckout"]');
        if (proceedBtn) setTimeout(() => proceedBtn.click(), 1000);
        return;
    }

    // Step 2: Address Page -> Select Address
    if (url.includes('buy/spc') || url.includes('checkout')) {
        const addressBtn = document.querySelector('input[data-testid="Address_selectShipToThisAddress"], #shipToThisAddressButton');
        if (addressBtn) setTimeout(() => addressBtn.click(), 1000);
        return;
    }

    // Step 3: Payment Page -> Apply Coupon & Inject CVV
    if (url.includes('payselect')) {
        const data = await chrome.storage.local.get(['walletCards', 'couponCode']);
        
        // --- COUPON INJECTION ENGINE ---
        if (data.couponCode) {
            console.log(`[Bot] Found Coupon in Database: ${data.couponCode}. Applying...`);
            const promoInput = document.querySelector('input[name="ppw-claimCode"]');
            const promoApplyBtn = document.querySelector('input[name="ppw-claimCodeApplyPressed"]');

            if (promoInput && promoApplyBtn) {
                promoInput.value = data.couponCode;
                promoInput.dispatchEvent(new Event('input', { bubbles: true }));
                promoApplyBtn.click();
                
                // Wait 2.5 seconds for Amazon to calculate the discount before paying
                await new Promise(r => setTimeout(r, 2500));
            }
        }

        // --- AGGRESSIVE CVV INJECTION ENGINE ---
        if (!data.walletCards) return;
        const activeCards = data.walletCards.filter(c => c.last4 && c.cvv && c.last4.length >= 2);
        
        for (let card of activeCards) {
            // Aggressive scan for the card row containing the Last 4 digits
            const allPaymentRows = document.querySelectorAll('.pmts-instrument-box, .payment-row, [data-pmts-component-id]');
            let targetRow = null;

            for (let row of allPaymentRows) {
                if (row.innerText.includes(card.last4) || row.innerHTML.includes(card.last4)) {
                    targetRow = row;
                    break;
                }
            }

            if (targetRow) {
                console.log(`[Bot] Found matching card ending in ${card.last4}`);
                
                // 1. Click the radio button to select the card
                const radioBtn = targetRow.querySelector('input[type="radio"]');
                if (radioBtn && !radioBtn.checked) {
                    radioBtn.click();
                    // Wait 1.5s for Amazon's JavaScript to animate the CVV box open
                    await new Promise(r => setTimeout(r, 1500)); 
                }

                // 2. Find the dynamically loaded CVV input
                const cvvInput = targetRow.querySelector('input[name="addCreditCardVerificationNumber"], input[type="password"], input[name*="cvv"]');
                
                if (cvvInput) {
                    cvvInput.value = card.cvv;
                    cvvInput.dispatchEvent(new Event('input', { bubbles: true }));
                    cvvInput.dispatchEvent(new Event('change', { bubbles: true }));
                    console.log(`[Bot] Injected CVV for card ${card.last4}`);
                    
                    // 3. Submit the payment
                    const continueBtn = document.querySelector('input[name="ppw-widgetEvent:SetPaymentPlanSelectContinueEvent"], #ppw-btn-continue');
                    if (continueBtn) {
                        setTimeout(() => continueBtn.click(), 1000);
                        break; // Stop loop once a card is successfully applied
                    }
                }
            }
        }
    }
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runCheckoutEngine);
} else {
    setTimeout(runCheckoutEngine, 1500);
}

// ==========================================
// OTP INJECTION LISTENER
// ==========================================
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'PHYSICALLY_TYPE_OTP') {
        console.log("[Bot] Received OTP:", message.otp);
        
        // Amazon uses different IDs depending on the auth type. This targets all of them.
        const otpInputs = document.querySelectorAll('input[name="code"], input[name="otpCode"], #cvf-input-code, #auth-mfa-otpcode');
        
        if (otpInputs.length > 0) {
            // Type the OTP
            otpInputs[0].value = message.otp;
            otpInputs[0].dispatchEvent(new Event('input', { bubbles: true }));
            otpInputs[0].dispatchEvent(new Event('change', { bubbles: true }));
            
            // Automatically click the Verify/Submit button
            const submitBtn = document.querySelector('#cvf-submit-otp-button .a-button-input, #auth-mfa-remember-device, input[type="submit"]');
            if (submitBtn) {
                setTimeout(() => submitBtn.click(), 500);
            }
        } else {
            console.warn("[Bot] No OTP input fields found on this page.");
        }
    }
});