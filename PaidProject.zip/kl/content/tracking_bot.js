// content/tracking_bot.js
async function scrapeTrackingData() {
    const url = window.location.href;

    if (url.includes('/progress-tracker/package')) {
        console.log("[Bot] Analyzing Live Tracking Data...");
        
        let trackingId = 'N/A';
        let courier = 'Amazon Logistics';
        let status = 'processing';
        
        const pageText = document.body.innerText.toLowerCase();
        
        // 1. Determine Status
        if (pageText.includes('delivered')) {
            status = 'delivered';
        } else if (pageText.includes('out for delivery')) {
            status = 'out_for_delivery';
        } else if (pageText.includes('shipped') || pageText.includes('on the way')) {
            status = 'shipped';
        }

        // 2. Extract Tracking ID & Courier using generic scraping rules
        const allTextElements = Array.from(document.querySelectorAll('span, div'));
        for (let el of allTextElements) {
            const text = el.innerText;
            // Look for "Tracking ID: XXXXXXX"
            const trackingMatch = text.match(/Tracking ID:?\s*([A-Z0-9]+)/i);
            if (trackingMatch && trackingMatch[1]) {
                trackingId = trackingMatch[1];
            }
            // Look for Carrier Info
            if (text.includes('Shipped with')) {
                courier = text.replace('Shipped with', '').trim();
            }
        }

        // Send data back to background.js to save to Supabase
        chrome.runtime.sendMessage({
            action: 'TRACKING_SCRAPED',
            tracking_id: trackingId,
            courier: courier,
            tracking_status: status
        });
    }
}

// Wait 2.5 seconds for Amazon's dynamic tracking page to load
setTimeout(scrapeTrackingData, 2500);