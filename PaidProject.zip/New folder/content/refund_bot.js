// content/refund_bot.js
async function executeRefundInjection() {
    const url = window.location.href;

    if (url.includes('/gp/your-account/order-details')) {
        console.log("[Bot] Analyzing Order Details for Return/Cancel options...");
        
        // 1. Look for the "Cancel items" button (if not shipped yet)
        const cancelBtn = document.querySelector('a[href*="cancel.html"]');
        
        // 2. Look for the "Return or replace items" button (if delivered)
        const returnBtn = document.querySelector('a[href*="/spr/returns"]');

        if (cancelBtn) {
            console.log("[Bot] Initiating Pre-Shipment Cancellation.");
            cancelBtn.click();
        } else if (returnBtn) {
            console.log("[Bot] Initiating Post-Delivery Return.");
            returnBtn.click();
        } else {
            console.log("[Bot] No Cancel or Return options available for this order.");
        }
    }
    
    // Automatically clicks the final confirmation on the following cancellation page
    if (url.includes('cancel.html') || url.includes('/spr/returns')) {
        const confirmBtn = document.querySelector('input[name="cancel.submit"], input[type="submit"]');
        if (confirmBtn) {
            setTimeout(() => confirmBtn.click(), 1000);
        }
    }
}

// Wait 2 seconds for the order page to fully load
setTimeout(executeRefundInjection, 2000);