async function executeCartInjection() {
    const url = window.location.href;

    // ==========================================
    // PHASE 1: SEARCH PAGE NAVIGATOR (/s)
    // ==========================================
    if (url.includes('/s?') || url.includes('/s/')) {
        const data = await chrome.storage.local.get(['targetName']);
        const searchTerm = data.targetName ? data.targetName.toLowerCase().trim() : '';

        let attempts = 0;
        const searchInterval = setInterval(() => {
            attempts++;
            
            // STRICT TARGETING: Only grab authentic Amazon search result cards
            const productBlocks = Array.from(document.querySelectorAll('div[data-component-type="s-search-result"]'));
                
            if (productBlocks.length > 0) {
                clearInterval(searchInterval);
                let targetHref = null;
                
                for (let block of productBlocks) {
                    // Skip if Amazon labeled it as Sponsored
                    if (block.innerText.includes('Sponsored') || block.innerText.includes('sponsored')) continue;

                    const linkTag = block.querySelector('h2 a');
                    if (linkTag && linkTag.href) {
                        // Save the very first organic link as a baseline fallback
                        if (!targetHref) targetHref = linkTag.href; 
                        
                        // EXACT MATCH OVERRIDE: Check if this product matches the exact name you uploaded
                        const titleText = block.innerText.toLowerCase();
                        if (searchTerm && !searchTerm.startsWith('http') && searchTerm.length > 5) {
                            // Match against the first 20 characters of your provided name
                            const searchSnippet = searchTerm.substring(0, 20);
                            if (titleText.includes(searchSnippet)) {
                                targetHref = linkTag.href;
                                break; // Perfect match found, stop looking
                            }
                        } else {
                            break; // If you uploaded a URL, just take the first organic product
                        }
                    }
                }
                
                // Final Fallback: if everything failed, grab the absolute top link
                if (!targetHref && productBlocks[0]) {
                    const fallbackLink = productBlocks[0].querySelector('h2 a');
                    if (fallbackLink) targetHref = fallbackLink.href;
                }

                // Navigate directly to the product in the SAME tab
                if (targetHref) {
                    window.location.replace(targetHref);
                } else {
                    chrome.runtime.sendMessage({ action: 'ITEM_CARTED' }); 
                }
            } else if (attempts >= 15) {
                // Failsafe: Move to next item if page is entirely broken after 7 seconds
                clearInterval(searchInterval);
                chrome.runtime.sendMessage({ action: 'ITEM_CARTED' });
            }
        }, 500);
        
        return; // Stop execution here. Wait for the new /dp/ product page to load.
    }

    // ==========================================
    // PHASE 2: PRODUCT PAGE INJECTOR (/dp/)
    // ==========================================
    const data = await chrome.storage.local.get(['orderQuantity']);
    const desiredQty = data.orderQuantity ? parseInt(data.orderQuantity) : 1;
    
    // Inject Quantity
    if (desiredQty > 1) {
        const selectEl = document.querySelector('select#quantity');
        if (selectEl) {
            selectEl.value = desiredQty.toString();
            selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        }
        document.querySelectorAll('input[name="quantity"], input#quantity').forEach(input => {
            input.value = desiredQty.toString();
        });
        const promptText = document.querySelector('.a-dropdown-prompt');
        if (promptText) promptText.innerText = desiredQty.toString();
        await new Promise(r => setTimeout(r, 1200)); 
    }

    // Scrape Final Price for the Dashboard
    let priceElement = document.querySelector('.a-price-whole');
    let unitPrice = priceElement ? parseFloat(priceElement.innerText.replace(/,/g, '')) : 0;
    let taxableValue = unitPrice * desiredQty;
    let gstAmount = taxableValue * 0.18;

    const cartBtn = document.querySelector('#add-to-cart-button') || document.querySelector('input[name="submit.add-to-cart"]');
    
    if (cartBtn) {
        ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(eventType => {
            cartBtn.dispatchEvent(new MouseEvent(eventType, { bubbles: true, cancelable: true }));
        });
        
        setTimeout(() => { 
            chrome.runtime.sendMessage({ action: 'ITEM_CARTED', taxable_value: taxableValue, gst_amount: gstAmount }); 
        }, 2500);
    } else {
        chrome.runtime.sendMessage({ action: 'ITEM_CARTED', taxable_value: 0, gst_amount: 0 }); 
    }
}
// Listens for OTP injection from the Dashboard
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'PHYSICALLY_TYPE_OTP') {
        console.log("[Bot] Received OTP:", message.otp);
        
        // Amazon uses different IDs depending on the auth type. This targets all of them.
        const otpInputs = document.querySelectorAll('input[name="code"], input[name="otpCode"], #cvf-input-code, #auth-mfa-otpcode');
        
        if (otpInputs.length > 0) {
            // Type the OTP
            otpInputs[0].value = message.otp;
            otpInputs[0].dispatchEvent(new Event('input', { bubbles: true }));
            otpInputs[0].dispatchEvent(new Event('change', { bubbles: true }));
            
            // Automatically click the Verify/Submit button
            const submitBtn = document.querySelector('#cvf-submit-otp-button .a-button-input, #auth-mfa-remember-device, input[type="submit"]');
            if (submitBtn) {
                setTimeout(() => submitBtn.click(), 500);
            }
        } else {
            console.warn("[Bot] No OTP input fields found on this page.");
        }
    }
});
// Start bot automatically
setTimeout(executeCartInjection, 1500);