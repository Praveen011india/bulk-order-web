/**
 * FILE: PaidProject/content/flipkart_bot.js
 * 🟢 FLIPKART AUTOMATION ENGINE - FULL VERSION (PARTS 3, 4, 5, 6) 🟢
 */

// ==========================================
// 1. UTILITIES & HIGHLIGHTER
// ==========================================
function highlight(el, color = "#2874f0") { 
    if (el) {
        el.style.border = `3px solid ${color}`; 
        el.style.boxShadow = `0 0 10px ${color}`;
        el.style.transition = "all 0.3s";
    }
}

function godModeClick(element) {
    if (!element) return;
    highlight(element);
    try { element.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    
    if (element.type === 'radio' || element.type === 'checkbox') element.checked = true;
    
    ['pointerdown', 'mousedown', 'focus', 'mouseup', 'pointerup', 'click'].forEach(evt => {
        element.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true, view: window }));
    });
}

function setNativeValue(element, value) {
    if (!element) return;
    highlight(element);
    element.focus();
    
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (valueSetter && valueSetter.set) valueSetter.set.call(element, value);
    else element.value = value;
    
    ['input', 'change', 'blur'].forEach(evt => {
        element.dispatchEvent(new Event(evt, { bubbles: true }));
    });
}

async function waitForElement(selector, timeout = 7000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el && el.offsetParent !== null) return el; 
        await new Promise(r => setTimeout(r, 200));
    }
    return null;
}

function getElementByText(selector, text) {
    const elements = document.querySelectorAll(selector);
    return Array.from(elements).find(el => el.textContent.trim().toLowerCase() === text.toLowerCase());
}

function getElementByPartialText(selector, text) {
    const elements = document.querySelectorAll(selector);
    return Array.from(elements).find(el => el.textContent.trim().toLowerCase().includes(text.toLowerCase()));
}

// ==========================================
// 2. DATA EXTRACTION ENGINE
// ==========================================
async function getPromoPreferences() {
    return new Promise((resolve) => {
        if (window.chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['useSuperCoins', 'couponCode'], (result) => {
                resolve({
                    useSuperCoins: result.useSuperCoins !== false, 
                    couponCode: result.couponCode || null
                });
            });
        } else {
            resolve({ useSuperCoins: true, couponCode: null });
        }
    });
}

async function getRealWalletData() {
    return new Promise((resolve) => {
        if (window.chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['walletCards'], (result) => {
                resolve(result.walletCards || []);
            });
        } else {
            resolve([]);
        }
    });
}

// ==========================================
// 3. MAIN FLIPKART ENGINE
// ==========================================
async function runFlipkartEngine() {
    const url = window.location.href;
    console.log("🚀 [FLIPKART BOT] Engine observing page state...");

    // ----------------------------------------------------------------
    // STAGE 1: CART PAGE -> CLICK "PLACE ORDER"
    // ----------------------------------------------------------------
    if (url.includes('/viewcart') || url.includes('/cart')) {
        console.log("🛒 [FLIPKART BOT] Cart Page Detected.");
        await new Promise(r => setTimeout(r, 1500)); 

        const placeOrderBtn = getElementByText('button, span, div', 'Place Order') || 
                              getElementByText('button, span, div', 'PLACE ORDER');

        if (placeOrderBtn) { godModeClick(placeOrderBtn); }
        return; 
    }

    // ----------------------------------------------------------------
    // STAGE 2: CHECKOUT PAGE -> ADDRESS & SUMMARY
    // ----------------------------------------------------------------
    if (url.includes('/checkout')) {
        console.log("📦 [FLIPKART BOT] Checkout Page Detected.");
        await new Promise(r => setTimeout(r, 2000)); 

        // 2A: Address Button
        const deliverHereBtn = getElementByText('button', 'Deliver Here') || getElementByText('button', 'DELIVER HERE');
        if (deliverHereBtn) {
            console.log("✅ [FLIPKART BOT] Selecting address...");
            godModeClick(deliverHereBtn);
            await new Promise(r => setTimeout(r, 2000)); 
        }

        // 2B: Order Summary Button
        const continueBtn = getElementByText('button', 'Continue') || getElementByText('button', 'CONTINUE') || getElementByText('button', 'Accept & Continue');
        if (continueBtn && !continueBtn.disabled) {
            console.log("✅ [FLIPKART BOT] Proceeding to Payment...");
            godModeClick(continueBtn);
            await new Promise(r => setTimeout(r, 2500)); 
        }

        // ----------------------------------------------------------------
        // STAGE 3: SUPERCOINS INJECTION 
        // ----------------------------------------------------------------
        const promoData = await getPromoPreferences();
        if (promoData.useSuperCoins) {
            const superCoinElement = getElementByPartialText('label, div, span', 'SuperCoin');
            if (superCoinElement) {
                const container = superCoinElement.closest('label, div');
                const checkbox = container ? container.querySelector('input[type="checkbox"]') : null;

                if (checkbox && !checkbox.checked) {
                    console.log("🪙 [FLIPKART BOT] Applying SuperCoins!");
                    godModeClick(checkbox);
                    await new Promise(r => setTimeout(r, 2000)); 
                } else if (!checkbox && container) {
                    console.log("🪙 [FLIPKART BOT] Clicking SuperCoin toggle!");
                    godModeClick(container);
                    await new Promise(r => setTimeout(r, 2000));
                }
            }
        }

        // ----------------------------------------------------------------
        // STAGE 4: PAYMENT SELECTION & CVV INJECTION
        // ----------------------------------------------------------------
        console.log("💳 [FLIPKART BOT] Initiating Payment Phase...");
        
        const allCards = await getRealWalletData();
        const activeCards = allCards.filter(c => c.last4 && c.cvv);

        if (activeCards.length === 0) {
            console.error("❌ [FLIPKART BOT] No active cards found in Dashboard Vault!");
            return;
        }

        const targetCard = activeCards[0];
        const last4 = String(targetCard.last4).trim();
        console.log(`🔍 [FLIPKART BOT] Looking for saved card ending in ${last4}...`);

        let targetRow = null;
        let foundCard = false;

        for (let attempts = 0; attempts < 3; attempts++) {
            const allLabels = document.querySelectorAll('label, div');
            targetRow = Array.from(allLabels).find(el => el.innerText && el.innerText.includes(last4) && (el.innerText.includes('**') || el.innerText.toLowerCase().includes('card')));

            if (targetRow) {
                foundCard = true;
                break;
            }

            const ccMenu = getElementByPartialText('label, div, span', 'Credit / Debit / ATM Card') || 
                           getElementByPartialText('label, div, span', 'Credit / Debit');
            if (ccMenu) {
                console.log("🔄 [FLIPKART BOT] Expanding Credit/Debit Card menu...");
                godModeClick(ccMenu);
                await new Promise(r => setTimeout(r, 1500));
            }
        }

        if (foundCard && targetRow) {
            console.log(`✅ [FLIPKART BOT] Found Card ${last4}! Selecting...`);
            
            const radioBtn = targetRow.querySelector('input[type="radio"]');
            if (radioBtn && !radioBtn.checked) godModeClick(radioBtn);
            else godModeClick(targetRow); 

            console.log("⏳ [FLIPKART BOT] Waiting for CVV box...");
            const cvvInput = await waitForElement('input[type="password"], input[name="cvv"]', 4000);
            
            if (cvvInput) {
                console.log("✅ [FLIPKART BOT] CVV Box Found! Injecting securely...");
                setNativeValue(cvvInput, targetCard.cvv);
                
                await new Promise(r => setTimeout(r, 1000)); 
                
                const allButtons = document.querySelectorAll('button');
                let payBtn = Array.from(allButtons).find(b => b.innerText.trim().toUpperCase().startsWith('PAY'));
                
                if (payBtn) {
                    console.log("🚀 [FLIPKART BOT] Clicking PAY!");
                    godModeClick(payBtn);
                    console.log("⏸️ [FLIPKART BOT] Awaiting Bank/OTP Redirect (Part 6).");
                } else {
                    console.error("❌ [FLIPKART BOT] Could not find the final PAY button.");
                }
            } else {
                console.error("❌ [FLIPKART BOT] CVV input box did not appear.");
            }
        } else {
            console.error(`❌ [FLIPKART BOT] The card ending in ${last4} is NOT SAVED on this Flipkart account.`);
        }
    }
}

// ==========================================
// 4. EXECUTION TRIGGERS
// ==========================================
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runFlipkartEngine);
} else {
    runFlipkartEngine();
}

window.addEventListener('hashchange', runFlipkartEngine);
window.addEventListener('popstate', runFlipkartEngine);


// ==========================================
// 5. OTP GATE INTEGRATION (PART 6)
// ==========================================
if (window.chrome && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === 'PHYSICALLY_TYPE_OTP') {
            console.log(`🔐 [FLIPKART BOT] OTP Received from Dashboard! Injecting: ${message.otp}`);
            
            // Look for generic OTP inputs (Banks and Flipkart use different names)
            const otpInput = document.querySelector('input[name="otp"], input[name="OTP"], input[id="otp"], input[type="password"], input[placeholder*="OTP" i]');
            
            if (otpInput) {
                setNativeValue(otpInput, message.otp);
                
                // Find the Submit/Verify button
                const allButtons = document.querySelectorAll('button, input[type="submit"], input[type="button"]');
                const submitBtn = Array.from(allButtons).find(b => {
                    const text = (b.innerText || b.value || "").toUpperCase();
                    return text.includes('SUBMIT') || text.includes('VERIFY') || text.includes('CONFIRM') || text.includes('PAY');
                });

                if (submitBtn) {
                    setTimeout(() => godModeClick(submitBtn), 500);
                    console.log("🚀 [FLIPKART BOT] OTP Submitted to Gateway!");
                } else {
                    console.warn("⚠️ [FLIPKART BOT] OTP Injected, but could not find the Submit button. Please click it manually.");
                }
            } else {
                console.error("❌ [FLIPKART BOT] Could not find the OTP input box on this screen.");
            }
        }
    });
}