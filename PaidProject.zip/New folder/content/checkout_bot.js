/**
 * FILE: PaidProject/content/checkout_bot.js
 * 🟢 REAL PRODUCTION SCRIPT - READS FROM DASHBOARD VAULT 🟢
 */

// ==========================================
// 1. UTILITIES & HIGHLIGHTER
// ==========================================
function highlight(el) {
    if (el) {
        el.style.border = "3px solid #10b981"; 
        el.style.boxShadow = "0 0 10px #10b981";
        el.style.transition = "all 0.3s";
    }
}

function godModeClick(element) {
    if (!element) return;
    highlight(element);
    try { element.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    
    if (element.type === 'radio') element.checked = true;
    
    ['pointerdown', 'mousedown', 'focus', 'mouseup', 'pointerup', 'click'].forEach(evt => {
        element.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true, view: window }));
    });
}

function setNativeValue(element, value) {
    if (!element) return;
    highlight(element);
    element.focus();
    
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (valueSetter && valueSetter.set) valueSetter.set.call(element, value);
    else element.value = value;
    
    ['input', 'change', 'blur'].forEach(evt => {
        element.dispatchEvent(new Event(evt, { bubbles: true }));
    });
}

async function waitForElement(selector, timeout = 7000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el && el.offsetParent !== null) return el; 
        await new Promise(r => setTimeout(r, 200));
    }
    return null;
}

// ==========================================
// 2. DATA EXTRACTION ENGINE (REAL DATA)
// ==========================================
async function getRealWalletData() {
    return new Promise((resolve) => {
        if (window.chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['walletCards'], (result) => {
                resolve(result.walletCards || []);
            });
        } else {
            resolve([]);
        }
    });
}

// ==========================================
// 3. MAIN BOT EXECUTION
// ==========================================
async function runCheckoutEngine() {
    const url = window.location.href;

    // --- CART PAGE ---
    if (url.includes('/cart')) {
        const proceedBtn = await waitForElement('input[name="proceedToRetailCheckout"]');
        if (proceedBtn) godModeClick(proceedBtn);
        return;
    }

    // --- PAYMENT PAGE ---
    if (url.includes('buy/spc') || url.includes('checkout') || url.includes('payselect')) {
        
        console.log("🚀 [BOT STARTING] Real Production Engine Active");
        await new Promise(r => setTimeout(r, 2000)); // Let Amazon fully load

        // 1. Fetch Real Data from Dashboard Vault
        const allCards = await getRealWalletData();
        const activeCards = allCards.filter(c => c.last4 && c.cvv);

        if (activeCards.length === 0) {
            alert("BOT WARNING: No cards found in the Dashboard Vault. Please go to your Dashboard, enter your Last 4 and CVV, and click 'Encrypt & Sync to Bot'.");
            return;
        }

        const targetCard = activeCards[0];
        const last4 = String(targetCard.last4).trim();
        console.log(`✅ [BOT] Successfully pulled card ending in ${last4} from Dashboard Vault.`);

        // 2. STRICTLY Find the "Credit or debit card" option (Avoids EMI bug)
        console.log("🔍 [BOT] Looking for 'Credit or debit card' menu...");
        const allRadios = document.querySelectorAll('input[type="radio"]');
        let ccRadio = null;
        
        for (let radio of allRadios) {
            const wrapperText = radio.closest('.a-box, label, div.a-row')?.innerText || "";
            // Look specifically for CC values or exact text
            if (radio.value.includes('CC') || wrapperText.includes('Credit or debit card')) {
                ccRadio = radio;
                break;
            }
        }

        if (ccRadio) {
            console.log("✅ [BOT] Opening Credit Card Menu...");
            godModeClick(ccRadio);
            const label = ccRadio.closest('label');
            if (label) godModeClick(label);
            
            await new Promise(r => setTimeout(r, 2500)); // Wait for cards to slide down
        } else {
            console.error("❌ [BOT] Could not find the 'Credit or debit card' section.");
        }

        // 3. Find the specific saved card matching the Dashboard's Last 4
        console.log(`🔍 [BOT] Scanning Amazon for saved card ending in ${last4}...`);
        const paymentRows = document.querySelectorAll('.ppw-instrument-row, .pmts-instrument-box, .payment-row');
        let targetRow = null;

        for (let row of paymentRows) {
            if (row.innerText && row.innerText.includes(last4)) {
                targetRow = row;
                break;
            }
        }

        if (targetRow) {
            console.log(`✅ [BOT] Found Card ${last4}! Selecting it...`);
            
            const cardRadio = targetRow.querySelector('input[type="radio"]');
            if (cardRadio) {
                godModeClick(cardRadio);
            } else {
                godModeClick(targetRow); // Fallback
            }

            // 4. Inject CVV from Dashboard
            console.log("⏳ [BOT] Waiting for CVV box...");
            const cvvInput = await waitForElement('input[name*="VerificationNumber"], input[placeholder*="CVV" i], input[type="password"]', 4000);
            
            if (cvvInput) {
                console.log(`✅ [BOT] CVV Box Found! Injecting CVV securely...`);
                setNativeValue(cvvInput, targetCard.cvv);
                
                await new Promise(r => setTimeout(r, 1000));
                
                // Click Continue
                const continueBtn = document.querySelector('input[name*="OrderOptionsContinueEvent"], input[name*="SelectContinueEvent"], #ppw-btn-continue');
                if (continueBtn) {
                    console.log("🚀 [BOT] Clicking Proceed!");
                    godModeClick(continueBtn);
                }
            } else {
                console.log("❌ [BOT] CVV box did not appear.");
            }
        } else {
            alert(`CLIENT DEMO NOTE: The bot is looking for the card ending in ${last4} from your Dashboard, but this Amazon account does not have that card saved yet. Please add it to your Amazon account manually first!`);
        }
    }
}

// Execute immediately
setTimeout(runCheckoutEngine, 1000);