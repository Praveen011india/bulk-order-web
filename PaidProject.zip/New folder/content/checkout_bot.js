async function runCheckoutEngine() {
    const url = window.location.href;

    // Safety check: Ensure the script is running inside a Chrome extension context
    if (typeof chrome === 'undefined' || !chrome.storage) {
        console.warn("[Bot] Chrome extension APIs not available. Are you running this as a content script?");
        return;
    }

    // ==========================================
    // PHASE 1: CART PAGE -> PROCEED TO BUY
    // ==========================================
    if (url.includes('/cart')) {
        const proceedBtn = document.querySelector('input[name="proceedToRetailCheckout"]');
        if (proceedBtn) {
            console.log("[Bot] Proceeding to Checkout...");
            setTimeout(() => proceedBtn.click(), 1000);
        }
        return; 
    }

    // ==========================================
    // PHASE 2: SINGLE PAGE CHECKOUT (Address, Promo, Payment)
    // ==========================================
    if (url.includes('buy/spc') || url.includes('checkout') || url.includes('payselect')) {
        
        // 1. Handle Address Selection
        const addressBtn = document.querySelector('input[data-testid="Address_selectShipToThisAddress"], #shipToThisAddressButton');
        if (addressBtn) {
            console.log("[Bot] Selecting Delivery Address...");
            addressBtn.click();
            await new Promise(r => setTimeout(r, 2000)); 
        }

        // Pull stored memory from the Background Worker safely
        let data = {};
        try {
            data = await chrome.storage.local.get(['walletCards', 'couponCode']);
        } catch (error) {
            console.error("[Bot] Failed to read from chrome.storage:", error);
            return;
        }

        // 2. --- COUPON INJECTION ENGINE ---
        if (data.couponCode) {
            console.log(`[Bot] Found Global Promo Code: ${data.couponCode}. Attempting to inject...`);
            
            let promoInput = document.querySelector('input[name="ppw-claimCode"], input[placeholder="Enter Code"], #spc-gcpromoinput, .pmts-claim-code');
            let promoApplyBtn = document.querySelector('input[name="ppw-claimCodeApplyPressed"], input[value="Apply"], .pmts-claim-code-apply-button input');

            if (!promoInput) {
                const allInputs = document.querySelectorAll('input[type="text"]');
                for (let inp of allInputs) {
                    if (inp.placeholder && inp.placeholder.toLowerCase().includes('enter code')) {
                        promoInput = inp;
                        break;
                    }
                }
            }

            if (!promoApplyBtn && promoInput) {
                const wrapper = promoInput.closest('div.a-row, div.flex, div, form');
                if (wrapper) promoApplyBtn = wrapper.querySelector('input[type="submit"], button, input[value="Apply"]');
            }

            if (promoInput && promoApplyBtn) {
                promoInput.value = data.couponCode;
                promoInput.dispatchEvent(new Event('input', { bubbles: true }));
                promoInput.dispatchEvent(new Event('change', { bubbles: true }));
                
                setTimeout(() => promoApplyBtn.click(), 500);
                await new Promise(r => setTimeout(r, 3000));
            }
        }

        // 3. --- AGGRESSIVE CVV INJECTION ENGINE ---
        if (data.walletCards && Array.isArray(data.walletCards)) {
            const activeCards = data.walletCards.filter(c => c.last4 && c.cvv && c.last4.length >= 2);
            console.log(`[Bot] Found ${activeCards.length} active cards in Vault.`);
            
            for (let card of activeCards) {
                const allPaymentRows = document.querySelectorAll('.ppw-instrument-row, .pmts-instrument-box, .payment-row');
                let targetRow = null;

                for (let row of allPaymentRows) {
                    if (row.innerText.includes(card.last4) || row.innerHTML.includes(card.last4)) {
                        targetRow = row;
                        break;
                    }
                }

                if (targetRow) {
                    console.log(`[Bot] Found matching card ending in ${card.last4}`);
                    
                    const radioBtn = targetRow.querySelector('input[type="radio"]');
                    if (radioBtn && !radioBtn.checked) {
                        radioBtn.click();
                        // CRITICAL: Wait 2.5 seconds for Amazon to request the CVV box via AJAX
                        await new Promise(r => setTimeout(r, 2500)); 
                    }

                    const cvvInput = targetRow.querySelector('input[name*="VerificationNumber"], input[type="password"], input[placeholder*="CVV"]');
                    
                    if (cvvInput) {
                        cvvInput.value = card.cvv;
                        cvvInput.dispatchEvent(new Event('input', { bubbles: true }));
                        cvvInput.dispatchEvent(new Event('change', { bubbles: true }));
                        console.log(`[Bot] Injected CVV for card ${card.last4}`);
                        
                        const continueBtn = document.querySelector('input[name*="OrderOptionsContinueEvent"], input[name*="SelectContinueEvent"], #ppw-btn-continue');
                        if (continueBtn) {
                            setTimeout(() => continueBtn.click(), 1000);
                            break; 
                        }
                    } else {
                        console.warn(`[Bot] Found card ${card.last4} but Amazon hid the CVV input box.`);
                    }
                }
            }
        }
    }
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runCheckoutEngine);
} else {
    setTimeout(runCheckoutEngine, 2000);
}

// ==========================================
// OTP INJECTION LISTENER
// ==========================================
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === 'PHYSICALLY_TYPE_OTP' && message.otp) {
            const otpInputs = document.querySelectorAll('input[name="code"], input[name="otpCode"], #cvf-input-code, #auth-mfa-otpcode');
            if (otpInputs.length > 0) {
                otpInputs[0].value = message.otp;
                otpInputs[0].dispatchEvent(new Event('input', { bubbles: true }));
                otpInputs[0].dispatchEvent(new Event('change', { bubbles: true }));
                
                const submitBtn = document.querySelector('#cvf-submit-otp-button .a-button-input, #auth-mfa-remember-device, input[type="submit"]');
                if (submitBtn) setTimeout(() => submitBtn.click(), 500);
            }
        }
    });
}