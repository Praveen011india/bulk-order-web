/**
 * FILE: PaidProject/content/checkout_bot.js
 * 🟢 AMAZON BUSINESS EDITION - SMART PO OBSERVER 🟢
 */

// ==========================================
// 1. UTILITIES & HIGHLIGHTER
// ==========================================
function highlight(el, color = "#10b981") {
    if (el) {
        el.style.border = `3px solid ${color}`; 
        el.style.boxShadow = `0 0 10px ${color}`;
        el.style.transition = "all 0.3s";
    }
}

function godModeClick(element) {
    if (!element) return;
    highlight(element);
    try { element.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e){}
    
    if (element.type === 'radio') element.checked = true;
    
    ['pointerdown', 'mousedown', 'focus', 'mouseup', 'pointerup', 'click'].forEach(evt => {
        element.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true, view: window }));
    });
}

function setNativeValue(element, value) {
    if (!element) return;
    highlight(element);
    element.focus();
    
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    if (valueSetter && valueSetter.set) valueSetter.set.call(element, value);
    else element.value = value;
    
    ['input', 'change', 'blur'].forEach(evt => {
        element.dispatchEvent(new Event(evt, { bubbles: true }));
    });
}

function getElementByText(selector, text) {
    const elements = document.querySelectorAll(selector);
    return Array.from(elements).find(el => el.textContent.trim().toLowerCase().includes(text.toLowerCase()));
}

// ==========================================
// 2. DATA EXTRACTION ENGINE (REAL DATA)
// ==========================================
async function getRealWalletData() {
    return new Promise((resolve) => {
        if (window.chrome && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['walletCards'], (result) => {
                resolve(result.walletCards || []);
            });
        } else {
            resolve([]);
        }
    });
}

// ==========================================
// 3. MAIN BOT EXECUTION (AMAZON BUSINESS)
// ==========================================
async function runCheckoutEngine() {
    const url = window.location.href;

    // --- CART PAGE ---
    if (url.includes('/cart')) {
        let attempts = 0;
        while(attempts < 10) {
            const proceedBtn = document.querySelector('input[name="proceedToRetailCheckout"]');
            if (proceedBtn) {
                godModeClick(proceedBtn);
                break;
            }
            await new Promise(r => setTimeout(r, 500));
            attempts++;
        }
        return;
    }

    // --- PAYMENT PAGE (AMAZON BUSINESS) ---
    if (url.includes('buy/spc') || url.includes('checkout') || url.includes('payselect')) {
        console.log("🚀 [BOT] Amazon Business Checkout Detected.");

        // 1. Fetch Real Data from Dashboard Vault
        const allCards = await getRealWalletData();
        const activeCards = allCards.filter(c => c.last4 && c.cvv);

        if (activeCards.length === 0) {
            console.error("❌ [BOT ERROR] No cards found in the Dashboard Vault!");
            return;
        }

        const targetCard = activeCards[0];
        const last4 = String(targetCard.last4).trim();
        console.log(`✅ [BOT] Loaded card ending in ${last4}. Entering PO Observation Mode...`);

        // ==============================================================
        // THE SMART OBSERVER LOOP: Waits infinitely for PO to be entered
        // ==============================================================
        let botExecuted = false;
        
        while (!botExecuted) {
            // Check every 1 second
            await new Promise(r => setTimeout(r, 1000));

            // OPTIONAL UX: Highlight the PO box to guide the user
            const poBox = document.querySelector('input[name*="purchaseOrder"], input[name*="poNumber"]');
            if (poBox && !poBox.value) highlight(poBox, "#f59e0b"); // Highlight orange

            // Step 1: Force open "Credit or debit card" if it's closed
            const ccRadios = document.querySelectorAll('input[type="radio"]');
            for (let radio of ccRadios) {
                const wrapperText = radio.closest('.a-box, label, div.a-row')?.innerText || "";
                if (radio.value.includes('CC') || wrapperText.includes('Credit or debit card')) {
                    if (!radio.checked && !radio.disabled) {
                        godModeClick(radio);
                        await new Promise(r => setTimeout(r, 1000)); // wait for slide
                    }
                    break;
                }
            }

            // Step 2: Scan for the saved card row
            const paymentRows = document.querySelectorAll('.ppw-instrument-row, .pmts-instrument-box, .payment-row');
            let targetRow = Array.from(paymentRows).find(row => row.innerText && row.innerText.includes(last4));

            if (targetRow) {
                // If the radio button is disabled (because PO isn't entered yet), ignore and keep looping
                const cardRadio = targetRow.querySelector('input[type="radio"]');
                if (cardRadio && cardRadio.disabled) {
                    continue; // Skip this loop iteration, wait for user to enter PO
                }

                // If we get here, the card is visible and unlocked!
                console.log(`✅ [BOT] Card ${last4} unlocked! Engaging auto-fill...`);
                
                if (cardRadio && !cardRadio.checked) {
                    godModeClick(cardRadio);
                } else if (!cardRadio) {
                    godModeClick(targetRow); 
                }

                // Step 3: Wait for CVV to pop up (Poll quickly)
                let cvvInput = null;
                for(let i=0; i<6; i++) {
                    await new Promise(r => setTimeout(r, 500));
                    cvvInput = document.querySelector('input[name*="VerificationNumber"], input[placeholder*="CVV" i], input[type="password"]');
                    if (cvvInput) break;
                }
                
                if (cvvInput) {
                    console.log(`✅ [BOT] CVV Box Found! Injecting securely...`);
                    setNativeValue(cvvInput, targetCard.cvv);
                    
                    await new Promise(r => setTimeout(r, 1000));
                    
                    // Step 4: Click Continue
                    const continueBtn = document.querySelector('input[name*="OrderOptionsContinueEvent"], input[name*="SelectContinueEvent"], #ppw-btn-continue');
                    if (continueBtn) {
                        console.log("🚀 [BOT] Clicking Proceed!");
                        godModeClick(continueBtn);
                        
                        // We are done! Kill the loop.
                        botExecuted = true;
                        break; 
                    }
                }
            }
        }
    }
}

// Execute immediately
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runCheckoutEngine);
} else {
    runCheckoutEngine();
}