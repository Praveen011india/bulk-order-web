/**
 * FILE: PaidProject/content/checkout_bot.js
 * 🟢 AMAZON BUSINESS (CRASH-PROOF EDITION) - PO BYPASS, CARD SELECTOR & AUTO-PROCEED 🟢
 */

(() => {
    // ------------------------------------------------------------------------
    // ANTI-DUPLICATION GUARD: Prevents SyntaxError if Chrome injects twice
    // ------------------------------------------------------------------------
    if (window.bobCheckoutEngineLoaded) return;
    window.bobCheckoutEngineLoaded = true;

    // ==========================================
    // 1. UTILITIES & AMAZON AUI CLICKER
    // ==========================================
    function highlight(el, color = "#10b981") {
        if (el && el.style) {
            el.style.border = `3px solid ${color}`;
            el.style.boxShadow = `0 0 12px ${color}`;
            el.style.transition = "all 0.3s";
        }
    }

    function isVisible(el) {
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && window.getComputedStyle(el).visibility !== 'hidden';
    }

    function godModeClick(element) {
        if (!element) return;
        highlight(element);
        try { element.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}

        if (element.type === 'radio' || element.type === 'checkbox') {
            element.checked = true;
        }

        ['pointerdown', 'mousedown', 'focus', 'mouseup', 'pointerup', 'click'].forEach(evt => {
            element.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true, view: window }));
        });

        try { element.click(); } catch (e) {}
    }

    function setNativeValue(element, value) {
        if (!element) return;
        highlight(element);
        element.focus();

        const valueSetter = Object.getOwnPropertyDescriptor(element, 'value') ||
                            Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
        if (valueSetter && valueSetter.set) {
            valueSetter.set.call(element, value);
        } else {
            element.value = value;
        }

        ['input', 'change', 'blur'].forEach(evt => {
            element.dispatchEvent(new Event(evt, { bubbles: true }));
        });
    }

    function clickAmazonYellowButton(buttonTextList) {
        const candidates = document.querySelectorAll('span.a-button-text, button, input[type="submit"], input[type="button"], a.a-button-text');

        for (const textToFind of buttonTextList) {
            const targetLower = textToFind.toLowerCase();

            for (const el of candidates) {
                const content = (el.innerText || el.value || el.textContent || '').trim().toLowerCase();
                if (content === targetLower && isVisible(el)) {
                    const buttonWrapper = el.closest('.a-button, button, [role="button"]') || el;
                    const innerInput = buttonWrapper.querySelector('input.a-button-input, input[type="submit"], input[type="button"], button');

                    highlight(buttonWrapper);
                    if (innerInput) {
                        godModeClick(innerInput);
                    }
                    godModeClick(buttonWrapper);
                    godModeClick(el);
                    return true;
                }
            }
        }
        return false;
    }

    function getRadioRowContainer(radio) {
        let current = radio.parentElement;
        let bestRow = current;
        for (let depth = 0; depth < 6 && current && current !== document.body; depth++) {
            const radiosInContainer = current.querySelectorAll('input[type="radio"]').length;
            if (radiosInContainer === 1) {
                bestRow = current;
                current = current.parentElement;
            } else {
                break;
            }
        }
        return bestRow || radio.closest('label, div, li, tr');
    }

    // ==========================================
    // 2. READ SAVED CARDS FROM EXTENSION STORAGE
    // ==========================================
    async function getRealWalletData() {
        return new Promise((resolve) => {
            try {
                if (window.chrome && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.get(['walletCards', 'wallet'], (result) => {
                        const cards = result.walletCards || result.wallet || [];
                        resolve(Array.isArray(cards) ? cards : []);
                    });
                } else {
                    resolve([]);
                }
            } catch (err) {
                resolve([]);
            }
        });
    }

    // ==========================================
    // 3. MAIN AMAZON BUSINESS CHECKOUT ENGINE
    // ==========================================
    let engineRunning = false; // Now safely protected inside the IIFE bubble

    async function runCheckoutEngine() {
        if (engineRunning) return;
        engineRunning = true;

        const url = window.location.href;

        // --- STAGE 1: CART PAGE ---
        if (url.includes('/cart') || url.includes('/gp/cart')) {
            for (let i = 0; i < 10; i++) {
                const proceedBtn = document.querySelector('input[name="proceedToRetailCheckout"], #sc-buy-box-ptc-button input');
                if (proceedBtn && isVisible(proceedBtn)) {
                    godModeClick(proceedBtn);
                    break;
                }
                await new Promise(r => setTimeout(r, 500));
            }
            engineRunning = false;
            return;
        }

        // --- STAGE 2: AMAZON BUSINESS CHECKOUT ---
        if (url.includes('/checkout') || url.includes('buy/spc') || url.includes('payselect') || url.includes('/gp/buy')) {
            console.log("🚀 [BOT] Amazon Business Checkout Engine Active.");

            let paymentCompleted = false;

            while (!paymentCompleted) {
                await new Promise(r => setTimeout(r, 1200));

                const pageText = document.body.innerText || '';
                const allRadios = Array.from(document.querySelectorAll('input[type="radio"]')).filter(isVisible);

                const cardsVisibleOnScreen = allRadios.some(r => {
                    const rowText = (getRadioRowContainer(r)?.innerText || '').toLowerCase();
                    return rowText.includes('ending in');
                });

                // STEP A: BYPASS PO NUMBER
                if (!cardsVisibleOnScreen && (pageText.includes('Business Order Information') || pageText.includes('PO number'))) {
                    console.log("⏩ [BOT] PO Number screen detected. Clicking 'Continue' to skip...");
                    const clickedPO = clickAmazonYellowButton(['Continue']);
                    if (clickedPO) {
                        await new Promise(r => setTimeout(r, 2200));
                        continue;
                    }
                }

                // STEP B: BYPASS DELIVERY ADDRESS
                const addressBtn = document.querySelector('input[data-testid="Address_selectShipToThisAddress"], #shipToThisAddressButton');
                if (addressBtn && isVisible(addressBtn)) {
                    console.log("📍 [BOT] Selecting Delivery Address...");
                    godModeClick(addressBtn);
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                } else if (!cardsVisibleOnScreen && clickAmazonYellowButton(['Deliver to this address', 'Use this address'])) {
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                }

                // STEP C: MATCH DASHBOARD CARD
                const allCards = await getRealWalletData();
                const activeCards = allCards.filter(c => c && c.last4 && String(c.last4).trim().length === 4);

                if (activeCards.length === 0) {
                    continue;
                }

                let matchedRadio = null;
                let matchedRow = null;
                let matchedCardData = null;

                for (const card of activeCards) {
                    const last4 = String(card.last4).trim();
                    for (const radio of allRadios) {
                        const row = getRadioRowContainer(radio);
                        const rowText = row ? row.innerText : '';
                        if (rowText.includes(`ending in ${last4}`) || rowText.includes(last4)) {
                            matchedRadio = radio;
                            matchedRow = row;
                            matchedCardData = card;
                            break;
                        }
                    }
                    if (matchedRadio) break;
                }

                if (matchedRadio && matchedRow && matchedCardData) {
                    const last4 = String(matchedCardData.last4).trim();
                    console.log(`✅ [BOT] Found saved card ending in ${last4}! Selecting it...`);

                    if (!matchedRadio.checked) {
                        godModeClick(matchedRadio);
                        const label = matchedRow.querySelector('label') || matchedRadio.closest('label');
                        if (label) godModeClick(label);
                        godModeClick(matchedRow);
                        await new Promise(r => setTimeout(r, 1500));
                    }

                    const cvvInputs = Array.from(
                        document.querySelectorAll('input[name*="VerificationNumber"], input[placeholder*="CVV" i], input[type="password"]')
                    ).filter(isVisible);

                    if (cvvInputs.length > 0 && matchedCardData.cvv) {
                        console.log("🔐 [BOT] CVV box detected. Injecting CVV...");
                        setNativeValue(cvvInputs[0], String(matchedCardData.cvv).trim());
                        await new Promise(r => setTimeout(r, 1000));
                    }

                    console.log("🚀 [BOT] Clicking 'Use this payment method'...");
                    const clickedPayMethod = clickAmazonYellowButton([
                        'Use this payment method',
                        'Continue',
                        'Continue to checkout'
                    ]);

                    if (!clickedPayMethod) {
                        const fallbackBtn = document.querySelector(
                            'input[name*="OrderOptionsContinueEvent"], input[name*="SelectContinueEvent"], #ppw-btn-continue, #checkout-primary-continue-button-id input'
                        );
                        if (fallbackBtn) godModeClick(fallbackBtn);
                    }

                    paymentCompleted = true;
                    break;
                } else {
                    const lookingFor = activeCards.map(c => c.last4).join(', ');
                    console.warn(`🔍 [BOT] Looking for card ending in [${lookingFor}] on this page...`);
                }
            }
        }

        engineRunning = false;
    }

    // ==========================================
    // 4. TRIGGER EXECUTION
    // ==========================================
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", runCheckoutEngine);
    } else {
        runCheckoutEngine();
    }
    window.addEventListener('hashchange', runCheckoutEngine);
    window.addEventListener('popstate', runCheckoutEngine);

})(); // End of IIFE Wrapper