// content/tracking_bot.js
async function runTrackingScraper() {
    const url = window.location.href;

    if (url.includes('/progress-tracker/package')) {
        console.log("[Bot] Analyzing Live Tracking Data via Text Node Scanner...");
        
        let trackingId = 'N/A';
        let courier = 'Amazon Logistics';
        let status = 'processing';
        
        // Pull all visual text from the page body
        const pageText = document.body.innerText.toUpperCase();
        
        // 1. Determine Exact Logistics Status
        if (pageText.includes('DELIVERED')) {
            status = 'delivered';
        } else if (pageText.includes('OUT FOR DELIVERY')) {
            status = 'out_for_delivery';
        } else if (pageText.includes('SHIPPED') || pageText.includes('ON THE WAY')) {
            status = 'shipped';
        }

        // 2. Extract Courier Name (Looks for "Shipped with [Courier Name]")
        const rawText = document.body.innerText;
        const courierMatch = rawText.match(/Shipped with\s+([A-Za-z\s]+)/i);
        if (courierMatch && courierMatch[1]) {
            courier = courierMatch[1].trim();
        }

        // 3. Extract AWB/Tracking ID (Looks for "Tracking ID: [Numbers]")
        const trackingMatch = rawText.match(/Tracking ID:?\s*([A-Z0-9]+)/i);
        if (trackingMatch && trackingMatch[1]) {
            trackingId = trackingMatch[1].trim();
        }

        console.log(`[Bot] Scraped Result -> Status: ${status} | Courier: ${courier} | AWB: ${trackingId}`);

        // Dispatch payload to background.js for Supabase patching
        chrome.runtime.sendMessage({
            action: 'TRACKING_SCRAPED',
            tracking_id: trackingId,
            courier: courier,
            tracking_status: status
        });
    }
}

// Wait 3.5 seconds for Amazon's dynamic tracking timeline map to render before scraping
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => setTimeout(runTrackingScraper, 3500));
} else {
    setTimeout(runTrackingScraper, 3500);
}