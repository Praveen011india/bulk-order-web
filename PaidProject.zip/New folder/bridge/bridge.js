/**
 * BulkOrderBuddy Enterprise - Content Bridge Relay
 * Relays events between Dashboard DOM and Chrome Extension Service Worker
 */

// 1. Credentials & Engine Sync
document.addEventListener('SyncBotCredentials', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_CREDENTIALS', 
        url: e.detail.url, 
        key: e.detail.key,
        userId: e.detail.userId
    });
});

// 2. Encrypted Payment Vault
document.addEventListener('SyncWalletCards', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_WALLET', 
        cards: e.detail.cards 
    });
});

// 3. Central Promo Coupon Engine
document.addEventListener('SyncGlobalCoupon', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_GLOBAL_COUPON', 
        coupon: e.detail.coupon 
    });
});

// 4. OTP Gate Interception
document.addEventListener('InjectAmazonOTP', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'FORWARD_OTP_TO_AMAZON', 
        otp: e.detail.otp 
    });
});

// 5. Automated Return / Cancellation Webhook
document.addEventListener('TriggerAmazonRefund', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_REFUND_BOT', 
        amazonOrderId: e.detail.amazonOrderId 
    });
});

// 6. Logistics Tracking Webhook
document.addEventListener('FetchAmazonTracking', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_TRACKING_BOT', 
        amazonOrderId: e.detail.amazonOrderId,
        dbOrderId: e.detail.dbOrderId 
    });
});

// 7. Cart Checkout Trigger
document.addEventListener('TriggerBatchCheckout', () => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_BATCH_CHECKOUT' 
    });
});

// 8. Keep-Alive Heartbeat (Prevents Manifest V3 Service Worker sleep)
setInterval(() => {
    chrome.runtime.sendMessage({ action: 'ANTI_SLEEP_PING' }).catch(() => {});
}, 20000);