/**
 * BulkOrderBuddy Enterprise - Content Bridge Relay (FIXED & CRASH-PROOF)
 * Relays events between Dashboard DOM and Chrome Extension Storage & Service Worker
 */

console.log("%c[BOB Bridge] Bridge Relay Loaded & Listening", "color: #10b981; font-weight: bold;");

// Helper: Safely check if the Chrome Extension context is still alive
function isExtensionValid() {
    try {
        return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
    } catch (err) {
        return false;
    }
}

// 1. Credentials & Engine Sync
document.addEventListener('SyncBotCredentials', (e) => {
    if (!isExtensionValid()) return;
    
    console.log("[Bridge] Syncing Bot Credentials...", e.detail);
    
    chrome.storage.local.set({
        supabaseUrl: e.detail.url,
        supabaseKey: e.detail.key,
        userId: e.detail.userId
    });
    
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_CREDENTIALS', 
        url: e.detail.url, 
        key: e.detail.key,
        userId: e.detail.userId
    }).catch(() => {});
});

// 2. Encrypted Payment Vault
document.addEventListener('SyncWalletCards', (e) => {
    if (!isExtensionValid()) {
        alert("⚠️ Extension was updated or reloaded in Chrome.\n\nPlease REFRESH this dashboard tab to restore the connection before syncing cards!");
        return;
    }

    const cards = e.detail.cards || [];
    console.log("%c[Bridge] 💳 SyncWalletCards Captured!", "color: #3b82f6; font-weight: bold;", cards);

    chrome.storage.local.set({ 
        walletCards: cards,
        wallet: cards 
    }, () => {
        console.log("%c[Bridge] ✅ Cards saved directly to chrome.storage.local!", "color: #10b981; font-weight: bold;");
    });

    chrome.runtime.sendMessage({ 
        action: 'UPDATE_WALLET', 
        cards: cards 
    }).catch(() => {});
});

// 3. Central Promo Coupon Engine
document.addEventListener('SyncGlobalCoupon', (e) => {
    if (!isExtensionValid()) return;
    console.log("[Bridge] Syncing Coupon:", e.detail.coupon);
    chrome.storage.local.set({ couponCode: e.detail.coupon });
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_GLOBAL_COUPON', 
        coupon: e.detail.coupon 
    }).catch(() => {});
});

// 4. OTP Gate Interception
document.addEventListener('InjectAmazonOTP', (e) => {
    if (!isExtensionValid()) return;
    console.log("[Bridge] Forwarding OTP:", e.detail.otp);
    chrome.runtime.sendMessage({ 
        action: 'FORWARD_OTP_TO_AMAZON', 
        otp: e.detail.otp 
    }).catch(() => {});
});

// 5. Automated Return / Cancellation Webhook
document.addEventListener('TriggerAmazonRefund', (e) => {
    if (!isExtensionValid()) return;
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_REFUND_BOT', 
        amazonOrderId: e.detail.amazonOrderId 
    }).catch(() => {});
});

// 6. Logistics Tracking Webhook
document.addEventListener('FetchAmazonTracking', (e) => {
    if (!isExtensionValid()) return;
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_TRACKING_BOT', 
        amazonOrderId: e.detail.amazonOrderId,
        dbOrderId: e.detail.dbOrderId 
    }).catch(() => {});
});

// 7. Cart Checkout Trigger
document.addEventListener('TriggerBatchCheckout', () => {
    if (!isExtensionValid()) return;
    chrome.runtime.sendMessage({ action: 'EXECUTE_BATCH_CHECKOUT' }).catch(() => {});
});

// 8. Keep-Alive Heartbeat (Prevents Manifest V3 Service Worker sleep)
const heartbeat = setInterval(() => {
    if (!isExtensionValid()) {
        // If extension is reloaded, instantly kill this interval so it never throws an error again.
        clearInterval(heartbeat);
        return;
    }
    chrome.runtime.sendMessage({ action: 'ANTI_SLEEP_PING' }).catch(() => {});
}, 20000);