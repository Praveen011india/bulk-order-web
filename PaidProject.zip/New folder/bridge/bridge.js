/**
 * BulkOrderBuddy Enterprise - Content Bridge Relay (FIXED)
 * Relays events between Dashboard DOM and Chrome Extension Storage & Service Worker
 */

console.log("%c[BOB Bridge] Bridge Relay Loaded & Listening", "color: #10b981; font-weight: bold;");

// 1. Credentials & Engine Sync
document.addEventListener('SyncBotCredentials', (e) => {
    console.log("[Bridge] Syncing Bot Credentials...", e.detail);
    if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({
            supabaseUrl: e.detail.url,
            supabaseKey: e.detail.key,
            userId: e.detail.userId
        });
    }
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_CREDENTIALS', 
        url: e.detail.url, 
        key: e.detail.key,
        userId: e.detail.userId
    }).catch(() => {});
});

// 2. Encrypted Payment Vault (DIRECT STORAGE FIX)
document.addEventListener('SyncWalletCards', (e) => {
    const cards = e.detail.cards || [];
    console.log("%c[Bridge] 💳 SyncWalletCards Captured!", "color: #3b82f6; font-weight: bold;", cards);

    // DIRECT WRITE: Save directly into Chrome Storage so checkout_bot.js can read it immediately
    if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ 
            walletCards: cards,
            wallet: cards 
        }, () => {
            console.log("%c[Bridge] ✅ Cards saved directly to chrome.storage.local!", "color: #10b981; font-weight: bold;");
        });
    }

    // Also forward to Service Worker as a backup
    try {
        chrome.runtime.sendMessage({ 
            action: 'UPDATE_WALLET', 
            cards: cards 
        }).catch(() => {});
    } catch(err) {}
});

// 3. Central Promo Coupon Engine
document.addEventListener('SyncGlobalCoupon', (e) => {
    console.log("[Bridge] Syncing Coupon:", e.detail.coupon);
    if (chrome && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ couponCode: e.detail.coupon });
    }
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_GLOBAL_COUPON', 
        coupon: e.detail.coupon 
    }).catch(() => {});
});

// 4. OTP Gate Interception
document.addEventListener('InjectAmazonOTP', (e) => {
    console.log("[Bridge] Forwarding OTP:", e.detail.otp);
    chrome.runtime.sendMessage({ 
        action: 'FORWARD_OTP_TO_AMAZON', 
        otp: e.detail.otp 
    }).catch(() => {});
});

// 5. Automated Return / Cancellation Webhook
document.addEventListener('TriggerAmazonRefund', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_REFUND_BOT', 
        amazonOrderId: e.detail.amazonOrderId 
    }).catch(() => {});
});

// 6. Logistics Tracking Webhook
document.addEventListener('FetchAmazonTracking', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_TRACKING_BOT', 
        amazonOrderId: e.detail.amazonOrderId,
        dbOrderId: e.detail.dbOrderId 
    }).catch(() => {});
});

// 7. Cart Checkout Trigger
document.addEventListener('TriggerBatchCheckout', () => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_BATCH_CHECKOUT' 
    }).catch(() => {});
});

// 8. Keep-Alive Heartbeat (Prevents Manifest V3 Service Worker sleep)
setInterval(() => {
    chrome.runtime.sendMessage({ action: 'ANTI_SLEEP_PING' }).catch(() => {});
}, 20000);