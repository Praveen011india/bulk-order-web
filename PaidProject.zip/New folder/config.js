/**
 * Configuration and Database Controller for PaidProject POC
 * Provides a lightweight REST wrapper for Supabase to avoid NPM bundling issues in Manifest V3.
 */

const CONFIG = {
    // Replace these with your actual Supabase project details before Monday
    SUPABASE_URL: 'https://kjcvmchftyeiccfpiemd.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtqY3ZtY2hmdHllaWNjZnBpZW1kIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgwMTM2MjcsImV4cCI6MjEwMzU4OTYyN30.m4wUParS14xU7FnAU3y-Eqtxjyvd3rNKFFrP0EL_Chk',
    
    // API endpoints
    ENDPOINTS: {
        ORDERS: '/rest/v1/bulk_orders', // Make sure this matches your Supabase table
        LOGS: '/rest/v1/bot_logs'
    },
    
    // Request configuration
    MAX_RETRIES: 3,
    TIMEOUT_MS: 10000
};

/**
 * SupabaseClient: Handles secure communication with the Supabase REST API
 */
class SupabaseClient {
    constructor() {
        this.headers = {
            'apikey': CONFIG.SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
        };
    }

    /**
     * Internal fetch handler with timeout and retry logic
     */
    async _request(endpoint, options = {}, retries = CONFIG.MAX_RETRIES) {
        const url = `${CONFIG.SUPABASE_URL}${endpoint}`;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), CONFIG.TIMEOUT_MS);
        
        try {
            const response = await fetch(url, {
                ...options,
                headers: { ...this.headers, ...options.headers },
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP Error: ${response.status}`);
            }

            return await response.json();

        } catch (error) {
            clearTimeout(timeoutId);
            
            if (retries > 0) {
                console.warn(`[Supabase] Request failed. Retrying... (${retries} left)`, error.message);
                // Exponential backoff
                await new Promise(res => setTimeout(res, 1000 * (CONFIG.MAX_RETRIES - retries + 1)));
                return this._request(endpoint, options, retries - 1);
            }
            
            console.error('[Supabase CRITICAL] Request permanently failed:', error);
            throw error;
        }
    }

    // --- DATABASE OPERATIONS ---

    /**
     * Log a new order initialization
     * @param {Object} orderData - { asin, quantity, platform, status }
     */
    async createOrderRecord(orderData) {
        return this._request(CONFIG.ENDPOINTS.ORDERS, {
            method: 'POST',
            body: JSON.stringify({
                ...orderData,
                created_at: new Date().toISOString()
            })
        });
    }

    /**
     * Update the status of an ongoing order
     * @param {string} orderId - The Supabase UUID
     * @param {string} newStatus - Current bot phase
     */
    async updateOrderStatus(orderId, newStatus) {
        return this._request(`${CONFIG.ENDPOINTS.ORDERS}?id=eq.${orderId}`, {
            method: 'PATCH',
            body: JSON.stringify({
                status: newStatus,
                updated_at: new Date().toISOString()
            })
        });
    }

    /**
     * Push application logs to the database for remote debugging
     * @param {string} level - 'INFO', 'WARNING', 'ERROR'
     * @param {string} message - Log description
     */
    async pushLog(level, message) {
        // We do not await this or retry it to prevent blocking the main bot thread
        fetch(`${CONFIG.SUPABASE_URL}${CONFIG.ENDPOINTS.LOGS}`, {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify({
                level,
                message,
                timestamp: new Date().toISOString()
            })
        }).catch(err => console.error('[Local Log Error]', err));
    }
}

// Export a singleton instance for use across the extension
const db = new SupabaseClient();