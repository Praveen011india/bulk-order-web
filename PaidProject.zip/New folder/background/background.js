/**
 * BulkOrderBuddy Enterprise - Master Service Worker
 * Manages Supabase Polling, Multi-Tab Automation, and DOM Webhooks
 */

const CONFIG = {
    URL: 'https://fsqdpnoygftookrcukdi.supabase.co',
    KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzcWRwbm95Z2Z0b29rcmN1a2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyMDY3MDYsImV4cCI6MjEwMzc4MjcwNn0.GpFEqhJ76N6KC5FDW4IaaZdJLcuCMkx5b787ptscUiU',
    USER_ID: null 
};

let isProcessing = false;
let activeTabId = null;

// Self-healing safety unlock: resets stale locks every 20 seconds
setInterval(() => {
    if (isProcessing) {
        isProcessing = false;
    }
}, 20000);

// Load persisted credentials on startup
chrome.storage.local.get(['supabaseUrl', 'supabaseKey', 'userId'], (data) => {
    if (data.supabaseUrl) CONFIG.URL = data.supabaseUrl;
    if (data.supabaseKey) CONFIG.KEY = data.supabaseKey;
    if (data.userId && data.userId !== 'undefined') CONFIG.USER_ID = data.userId;
    pollCartQueue();
});

// Regular polling loop
setInterval(pollCartQueue, 3000);

async function pollCartQueue() {
    if (isProcessing || !CONFIG.URL || !CONFIG.KEY) return;

    try {
        let endpoint = `${CONFIG.URL}/rest/v1/bulk_orders?status=eq.pending&limit=1`;
        if (CONFIG.USER_ID && CONFIG.USER_ID !== 'undefined' && CONFIG.USER_ID !== 'null') {
            endpoint += `&user_id=eq.${encodeURIComponent(CONFIG.USER_ID)}`;
        }

        const res = await fetch(endpoint, {
            headers: { 
                'apikey': CONFIG.KEY, 
                'Authorization': `Bearer ${CONFIG.KEY}` 
            }
        });

        if (!res.ok) return;
        const orders = await res.json();

        if (orders && orders.length > 0) {
            isProcessing = true;
            const order = orders[0];

            // Mark order as running
            await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${order.id}`, {
                method: 'PATCH',
                headers: { 
                    'apikey': CONFIG.KEY, 
                    'Authorization': `Bearer ${CONFIG.KEY}`, 
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify({ status: 'running' })
            });

            // Store order details for content scripts
            await chrome.storage.local.set({ 
                currentOrderId: order.id, 
                orderQuantity: order.quantity || 1,
                couponCode: order.coupon_code || '',
                targetName: order.asin
            });

            // Determine navigation target
            const cleanIdentifier = order.asin ? order.asin.trim() : '';
            let targetUrl = `https://www.amazon.in/dp/${cleanIdentifier}`;

            if (cleanIdentifier.startsWith('http')) {
                targetUrl = cleanIdentifier;
            } else if (!/^[A-Z0-9]{10}$/i.test(cleanIdentifier)) {
                targetUrl = `https://www.amazon.in/s?k=${encodeURIComponent(cleanIdentifier)}`;
            }

            routeToTab(targetUrl);
        }
    } catch (err) {
        console.error("[Background Engine] Polling error:", err);
        isProcessing = false;
    }
}

// Safely updates an existing tab or creates a new one if closed
function routeToTab(url) {
    if (activeTabId) {
        chrome.tabs.get(activeTabId, (tab) => {
            if (chrome.runtime.lastError || !tab) {
                chrome.tabs.create({ url: url, active: true }, (newTab) => {
                    activeTabId = newTab.id;
                });
            } else {
                chrome.tabs.update(activeTabId, { url: url, active: true });
            }
        });
    } else {
        chrome.tabs.create({ url: url, active: true }, (newTab) => {
            activeTabId = newTab.id;
        });
    }
}

// Message Bus Dispatcher
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 1. Keep-Alive Ping
    if (message.action === 'ANTI_SLEEP_PING') {
        if (sendResponse) sendResponse({ status: 'active' });
        return true;
    }

    // 2. Sync Credentials from Dashboard
    if (message.action === 'UPDATE_CREDENTIALS' || message.action === 'FORCE_EXTENSION_RESTART') {
        const url = message.url || (message.credentials && message.credentials.url);
        const key = message.key || (message.credentials && message.credentials.key);
        const userId = message.userId || (message.credentials && message.credentials.userId);

        if (url) CONFIG.URL = url;
        if (key) CONFIG.KEY = key;
        if (userId && userId !== 'undefined') CONFIG.USER_ID = userId;

        chrome.storage.local.set({ 
            supabaseUrl: CONFIG.URL, 
            supabaseKey: CONFIG.KEY, 
            userId: CONFIG.USER_ID 
        }, () => {
            isProcessing = false;
            pollCartQueue();
        });
    }

    // 3. Sync Wallet Cards
    if (message.action === 'UPDATE_WALLET') {
        chrome.storage.local.set({ walletCards: message.cards });
    }

    // 4. Sync Global Coupon
    if (message.action === 'UPDATE_GLOBAL_COUPON') {
        chrome.storage.local.set({ couponCode: message.coupon });
    }

    // 5. Forward OTP to Amazon Page
    if (message.action === 'FORWARD_OTP_TO_AMAZON' && activeTabId) {
        chrome.tabs.sendMessage(activeTabId, { 
            action: 'PHYSICALLY_TYPE_OTP', 
            otp: message.otp 
        });
    }

    // 6. Navigation Webhooks
    if (message.action === 'EXECUTE_REFUND_BOT') {
        isProcessing = true;
        routeToTab(`https://www.amazon.in/gp/your-account/order-details?orderID=${message.amazonOrderId}`);
    }

    if (message.action === 'EXECUTE_BATCH_CHECKOUT') {
        isProcessing = true;
        routeToTab('https://www.amazon.in/cart');
    }

    if (message.action === 'EXECUTE_TRACKING_BOT') {
        isProcessing = true;
        chrome.storage.local.set({ activeTrackingDbId: message.dbOrderId });
        routeToTab(`https://www.amazon.in/progress-tracker/package/?orderId=${message.amazonOrderId}`);
    }

    // 7. Scraper Callbacks
    if (message.action === 'TRACKING_SCRAPED') {
        chrome.storage.local.get(['activeTrackingDbId'], async (data) => {
            if (data.activeTrackingDbId && CONFIG.KEY) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.activeTrackingDbId}`, {
                    method: 'PATCH',
                    headers: { 
                        'apikey': CONFIG.KEY, 
                        'Authorization': `Bearer ${CONFIG.KEY}`, 
                        'Content-Type': 'application/json' 
                    },
                    body: JSON.stringify({
                        tracking_id: message.tracking_id,
                        courier: message.courier,
                        tracking_status: message.tracking_status
                    })
                });
            }
            isProcessing = false;
        });
    }

    if (message.action === 'ITEM_CARTED') {
        chrome.storage.local.get(['currentOrderId'], async (data) => {
            if (data.currentOrderId && CONFIG.KEY) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.currentOrderId}`, {
                    method: 'PATCH',
                    headers: { 
                        'apikey': CONFIG.KEY, 
                        'Authorization': `Bearer ${CONFIG.KEY}`, 
                        'Content-Type': 'application/json' 
                    },
                    body: JSON.stringify({
                        status: 'completed',
                        taxable_value: message.taxable_value || 0,
                        gst_amount: message.gst_amount || 0
                    })
                });
            }
            isProcessing = false;
        });
    }
});