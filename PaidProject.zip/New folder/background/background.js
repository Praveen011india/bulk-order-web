/**
 * FILE: PaidProject/background/background.js
 * BulkOrderBuddy Enterprise - Master Service Worker (V2.1 - Dual Platform)
 * Manages Supabase Polling, Multi-Tab Automation (Amazon + Flipkart), and DOM Webhooks
 */

const DEFAULT_URL = 'https://fsqdpnoygftookrcukdi.supabase.co';
const DEFAULT_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzcWRwbm95Z2Z0b29rcmN1a2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgyMDY3MDYsImV4cCI6MjEwMzc4MjcwNn0.GpFEqhJ76N6KC5FDW4IaaZdJLcuCMkx5b787ptscUiU';

const CONFIG = {
    URL: DEFAULT_URL,
    KEY: DEFAULT_KEY,
    USER_ID: null 
};

let isProcessing = false;
let activeTabId = null;

// Helper: Validate and clean Supabase URL to prevent "Failed to fetch"
function sanitizeUrl(url) {
    if (!url || typeof url !== 'string' || url === 'undefined' || url === 'null' || !url.startsWith('http')) {
        return DEFAULT_URL;
    }
    return url.trim().replace(/\/+$/, ''); // Remove trailing slashes
}

function sanitizeKey(key) {
    if (!key || typeof key !== 'string' || key === 'undefined' || key === 'null' || key.length < 20) {
        return DEFAULT_KEY;
    }
    return key.trim();
}

// Self-healing safety unlock: resets stale locks every 25 seconds
setInterval(() => {
    if (isProcessing) {
        isProcessing = false;
    }
}, 25000);

// Load persisted credentials on startup
chrome.storage.local.get(['supabaseUrl', 'supabaseKey', 'userId', 'activeTabId'], (data) => {
    CONFIG.URL = sanitizeUrl(data.supabaseUrl);
    CONFIG.KEY = sanitizeKey(data.supabaseKey);
    if (data.userId && data.userId !== 'undefined' && data.userId !== 'null') {
        CONFIG.USER_ID = data.userId;
    }
    if (data.activeTabId) {
        activeTabId = data.activeTabId;
    }
    pollCartQueue();
});

// Regular polling loop (every 3.5 seconds)
setInterval(pollCartQueue, 3500);

async function pollCartQueue() {
    if (isProcessing || !CONFIG.URL || !CONFIG.KEY) return;
    if (typeof navigator !== 'undefined' && !navigator.onLine) return; // Skip poll if offline

    try {
        const cleanBaseUrl = sanitizeUrl(CONFIG.URL);
        let endpoint = `${cleanBaseUrl}/rest/v1/bulk_orders?status=eq.pending&order=created_at.asc&limit=1`;
        
        if (CONFIG.USER_ID && CONFIG.USER_ID !== 'undefined' && CONFIG.USER_ID !== 'null') {
            endpoint += `&user_id=eq.${encodeURIComponent(CONFIG.USER_ID)}`;
        }

        // AbortController prevents hanging fetch calls from crashing the service worker
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        const res = await fetch(endpoint, {
            method: 'GET',
            headers: { 
                'apikey': CONFIG.KEY, 
                'Authorization': `Bearer ${CONFIG.KEY}`,
                'Accept': 'application/json'
            },
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!res.ok) return;
        const orders = await res.json();

        if (orders && orders.length > 0) {
            isProcessing = true;
            const order = orders[0];

            // 1. Mark order as running in Supabase
            await fetch(`${cleanBaseUrl}/rest/v1/bulk_orders?id=eq.${order.id}`, {
                method: 'PATCH',
                headers: { 
                    'apikey': CONFIG.KEY, 
                    'Authorization': `Bearer ${CONFIG.KEY}`, 
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify({ status: 'running' })
            });

            // 2. Determine Platform (Amazon vs Flipkart)
            const cleanIdentifier = order.asin ? order.asin.trim() : '';
            const platform = (order.platform || '').toLowerCase();
            const isFlipkart = platform === 'flipkart' || 
                               cleanIdentifier.toLowerCase().includes('flipkart.com') || 
                               cleanIdentifier.toUpperCase().startsWith('ITM') || 
                               cleanIdentifier.length === 16;

            // 3. Store order details in Chrome Storage for Content Scripts
            await chrome.storage.local.set({ 
                currentOrderId: order.id, 
                orderQuantity: order.quantity || 1,
                couponCode: order.coupon_code || '',
                useSuperCoins: order.supercoins_enabled !== false,
                targetName: cleanIdentifier,
                activePlatform: isFlipkart ? 'flipkart' : 'amazon'
            });

            // 4. Route to the exact platform URL
            let targetUrl = '';

            if (cleanIdentifier.startsWith('http')) {
                targetUrl = cleanIdentifier;
            } else if (isFlipkart) {
                // Route Flipkart FSN / PID / Search Query to Flipkart
                targetUrl = `https://www.flipkart.com/search?q=${encodeURIComponent(cleanIdentifier)}`;
            } else {
                // Route Amazon ASIN or Search Query to Amazon
                if (/^[A-Z0-9]{10}$/i.test(cleanIdentifier)) {
                    targetUrl = `https://www.amazon.in/dp/${cleanIdentifier}`;
                } else {
                    targetUrl = `https://www.amazon.in/s?k=${encodeURIComponent(cleanIdentifier)}`;
                }
            }

            routeToTab(targetUrl);
        }
    } catch (err) {
        // Using console.log instead of console.error prevents Chrome Extensions from flagging transient network blips
        console.log("[Background Engine] Poll skipped (Network/Database busy):", err.message);
        isProcessing = false;
    }
}

// Safely updates an existing tab or creates a new one if closed
function routeToTab(url) {
    if (activeTabId) {
        chrome.tabs.get(activeTabId, (tab) => {
            if (chrome.runtime.lastError || !tab) {
                chrome.tabs.create({ url: url, active: true }, (newTab) => {
                    activeTabId = newTab.id;
                    chrome.storage.local.set({ activeTabId: newTab.id });
                });
            } else {
                chrome.tabs.update(activeTabId, { url: url, active: true });
            }
        });
    } else {
        chrome.tabs.create({ url: url, active: true }, (newTab) => {
            activeTabId = newTab.id;
            chrome.storage.local.set({ activeTabId: newTab.id });
        });
    }
}

// Message Bus Dispatcher
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // 1. Keep-Alive Ping
    if (message.action === 'ANTI_SLEEP_PING') {
        if (sendResponse) sendResponse({ status: 'active' });
        return true;
    }

    // 2. Sync Credentials from Dashboard
    if (message.action === 'UPDATE_CREDENTIALS' || message.action === 'FORCE_EXTENSION_RESTART') {
        const url = message.url || (message.credentials && message.credentials.url);
        const key = message.key || (message.credentials && message.credentials.key);
        const userId = message.userId || (message.credentials && message.credentials.userId);

        CONFIG.URL = sanitizeUrl(url);
        CONFIG.KEY = sanitizeKey(key);
        if (userId && userId !== 'undefined' && userId !== 'null') {
            CONFIG.USER_ID = userId;
        }

        chrome.storage.local.set({ 
            supabaseUrl: CONFIG.URL, 
            supabaseKey: CONFIG.KEY, 
            userId: CONFIG.USER_ID 
        }, () => {
            isProcessing = false;
            pollCartQueue();
        });
        if (sendResponse) sendResponse({ synced: true });
        return true;
    }

    // 3. Sync Wallet Cards
    if (message.action === 'UPDATE_WALLET') {
        chrome.storage.local.set({ walletCards: message.cards || [] });
        if (sendResponse) sendResponse({ synced: true });
        return true;
    }

    // 4. Sync Global Coupon
    if (message.action === 'UPDATE_GLOBAL_COUPON') {
        chrome.storage.local.set({ couponCode: message.coupon || '' });
        if (sendResponse) sendResponse({ synced: true });
        return true;
    }

    // 5. Forward OTP to Active Amazon or Flipkart Tab
    if (message.action === 'FORWARD_OTP_TO_AMAZON') {
        if (activeTabId) {
            chrome.tabs.sendMessage(activeTabId, { 
                action: 'PHYSICALLY_TYPE_OTP', 
                otp: message.otp 
            }).catch(() => {});
        } else {
            // Fallback if service worker restarted: send to any open Amazon/Flipkart tab
            chrome.tabs.query({ url: ["*://*.amazon.in/*", "*://*.flipkart.com/*"] }, (tabs) => {
                tabs.forEach(tab => {
                    chrome.tabs.sendMessage(tab.id, { 
                        action: 'PHYSICALLY_TYPE_OTP', 
                        otp: message.otp 
                    }).catch(() => {});
                });
            });
        }
        if (sendResponse) sendResponse({ forwarded: true });
        return true;
    }

    // 6. Navigation Webhooks
    if (message.action === 'EXECUTE_REFUND_BOT') {
        isProcessing = true;
        routeToTab(`https://www.amazon.in/gp/your-account/order-details?orderID=${message.amazonOrderId}`);
    }

    if (message.action === 'EXECUTE_BATCH_CHECKOUT') {
        isProcessing = true;
        chrome.storage.local.get(['activePlatform'], (data) => {
            if (data.activePlatform === 'flipkart') {
                routeToTab('https://www.flipkart.com/viewcart');
            } else {
                routeToTab('https://www.amazon.in/cart');
            }
        });
    }

    if (message.action === 'EXECUTE_TRACKING_BOT') {
        isProcessing = true;
        chrome.storage.local.set({ activeTrackingDbId: message.dbOrderId });
        routeToTab(`https://www.amazon.in/progress-tracker/package/?orderId=${message.amazonOrderId}`);
    }

    // 7. Scraper & Completion Callbacks
    if (message.action === 'TRACKING_SCRAPED') {
        chrome.storage.local.get(['activeTrackingDbId'], async (data) => {
            if (data.activeTrackingDbId && CONFIG.KEY) {
                try {
                    await fetch(`${sanitizeUrl(CONFIG.URL)}/rest/v1/bulk_orders?id=eq.${data.activeTrackingDbId}`, {
                        method: 'PATCH',
                        headers: { 
                            'apikey': CONFIG.KEY, 
                            'Authorization': `Bearer ${CONFIG.KEY}`, 
                            'Content-Type': 'application/json' 
                        },
                        body: JSON.stringify({
                            tracking_id: message.tracking_id,
                            courier: message.courier,
                            tracking_status: message.tracking_status
                        })
                    });
                } catch (e) {}
            }
            isProcessing = false;
        });
    }

    if (message.action === 'ITEM_CARTED') {
        chrome.storage.local.get(['currentOrderId'], async (data) => {
            if (data.currentOrderId && CONFIG.KEY) {
                try {
                    await fetch(`${sanitizeUrl(CONFIG.URL)}/rest/v1/bulk_orders?id=eq.${data.currentOrderId}`, {
                        method: 'PATCH',
                        headers: { 
                            'apikey': CONFIG.KEY, 
                            'Authorization': `Bearer ${CONFIG.KEY}`, 
                            'Content-Type': 'application/json' 
                        },
                        body: JSON.stringify({
                            status: 'completed',
                            taxable_value: message.taxable_value || 0,
                            gst_amount: message.gst_amount || 0
                        })
                    });
                } catch (e) {}
            }
            isProcessing = false;
        });
    }
});