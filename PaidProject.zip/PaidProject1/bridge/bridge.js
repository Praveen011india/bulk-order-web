/**
 * ============================================================================
 * BULKORDERBUDDY ENTERPRISE: EXTENSION BRIDGE
 * Safely relays data from the Dashboard DOM to the Chrome Extension Backend
 * ============================================================================
 */

// 1. Core Synchronization & Anti-Sleep Auto-Reload
document.addEventListener('SyncBotCredentials', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'FORCE_EXTENSION_RESTART', 
        credentials: e.detail 
    });
});

// 2. Payment Vault Integration
document.addEventListener('SyncWalletCards', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_WALLET', 
        cards: e.detail.cards 
    });
});

// 3. Promo Engine Integration
document.addEventListener('SyncGlobalCoupon', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'UPDATE_GLOBAL_COUPON', 
        coupon: e.detail.coupon 
    });
});

// 4. Manual OTP Gate Injection
document.addEventListener('InjectAmazonOTP', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'FORWARD_OTP_TO_AMAZON', 
        otp: e.detail.otp 
    });
});

// 5. Automated Cancellation / Refund Webhook
document.addEventListener('TriggerAmazonRefund', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_REFUND_BOT', 
        amazonOrderId: e.detail.amazonOrderId 
    });
});

// 6. Logistics Tracking Webhook
document.addEventListener('FetchAmazonTracking', (e) => {
    chrome.runtime.sendMessage({ 
        action: 'EXECUTE_TRACKING_BOT', 
        amazonOrderId: e.detail.amazonOrderId, 
        dbOrderId: e.detail.dbOrderId 
    });
});

// 7. 1-Shot Cart Batching Trigger
document.addEventListener('TriggerBatchCheckout', () => {
    chrome.runtime.sendMessage({ action: 'EXECUTE_BATCH_CHECKOUT' });
});

// ==========================================
// THE ANTI-SLEEP HEARTBEAT
// Keeps the Chrome Extension awake while the dashboard is open.
// ==========================================
setInterval(() => {
    chrome.runtime.sendMessage({ action: 'ANTI_SLEEP_PING' }).catch(() => {});
}, 20000);