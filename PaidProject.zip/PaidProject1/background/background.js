/**
 * ============================================================================
 * BULKORDERBUDDY ENTERPRISE: BACKGROUND SERVICE WORKER
 * Manages Cloud Polling, Tab Routing, and Database Patching
 * ============================================================================
 */

let CONFIG = { URL: '', KEY: '', USER_ID: '' };
let isProcessing = false;
let activeTabId = null;

// ==========================================
// 1. BOOT SEQUENCE & CLOUD POLLING
// ==========================================

// Load credentials from storage on boot so they survive browser restarts
chrome.storage.local.get(['supabaseUrl', 'supabaseKey', 'userId'], (data) => {
    if (data.supabaseUrl && data.supabaseKey) {
        CONFIG.URL = data.supabaseUrl;
        CONFIG.KEY = data.supabaseKey;
        CONFIG.USER_ID = data.userId;
        console.log("[Bot Engine] Credentials authenticated. Initiating telemetry.");
        pollCartQueue();
        setInterval(pollCartQueue, 4000);
    } else {
        console.log("[Bot Engine] Awaiting Dashboard Synchronization...");
    }
});

async function pollCartQueue() {
    if (isProcessing || !CONFIG.URL || !CONFIG.KEY || !CONFIG.USER_ID) return;

    try {
        const endpoint = `${CONFIG.URL}/rest/v1/bulk_orders?status=eq.pending&user_id=eq.${encodeURIComponent(CONFIG.USER_ID)}&limit=1`;
        
        const res = await fetch(endpoint, {
            headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}` }
        });
        
        if (!res.ok) throw new Error("Database Fetch Failed");
        const orders = await res.json();

        if (orders && orders.length > 0) {
            isProcessing = true;
            const order = orders[0];
            
            // Mark as running
            await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${order.id}`, {
                method: 'PATCH',
                headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: 'running' })
            });

            // Save order data for Content Scripts
            await chrome.storage.local.set({ 
                currentOrderId: order.id, 
                orderQuantity: order.quantity || 1,
                couponCode: order.coupon_code || '',
                targetName: order.asin
            });

            // Smart Routing
            const cleanIdentifier = order.asin ? order.asin.trim() : '';
            const isAsin = /^[A-Z0-9]{10}$/i.test(cleanIdentifier);
            const isUrl = cleanIdentifier.startsWith('http');
            
            let targetUrl = '';
            if (isUrl) {
                targetUrl = cleanIdentifier; 
            } else if (isAsin) {
                targetUrl = `https://www.amazon.in/dp/${cleanIdentifier}`; 
            } else {
                targetUrl = `https://www.amazon.in/s?k=${encodeURIComponent(cleanIdentifier)}`; 
            }

            routeToTab(targetUrl);
            setTimeout(() => { isProcessing = false; }, 15000); // Failsafe unlock
        }
    } catch (e) {
        console.error("[Bot Engine] Execution Error:", e);
        isProcessing = false;
    }
}

// Helper: Safely reuses the same tab to avoid opening 100 windows
function routeToTab(url) {
    if (activeTabId) {
        chrome.tabs.update(activeTabId, { url: url, active: true }).catch(() => {
            chrome.tabs.create({ url: url, active: true }, (t) => activeTabId = t.id);
        });
    } else {
        chrome.tabs.create({ url: url, active: true }, (t) => activeTabId = t.id);
    }
}

// ==========================================
// 2. MESSAGE ROUTER (DASHBOARD -> BOT)
// ==========================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    
    // 1. Anti-Sleep Acknowledgment
    if (message.action === 'ANTI_SLEEP_PING') {
        if (sendResponse) sendResponse({ status: "awake" });
        return true;
    }

    // 2. Auto-Reload & Credential Sync
    if (message.action === 'FORCE_EXTENSION_RESTART') {
        chrome.storage.local.set({ 
            supabaseUrl: message.credentials.url,
            supabaseKey: message.credentials.key,
            userId: message.credentials.userId
        }, () => {
            console.log("[Bot Engine] Credentials synchronized. Rebooting systems.");
            chrome.runtime.reload();
        });
    }

    // 3. Modules Storage Memory
    if (message.action === 'UPDATE_WALLET') {
        chrome.storage.local.set({ walletCards: message.cards });
    }
    if (message.action === 'UPDATE_GLOBAL_COUPON') {
        chrome.storage.local.set({ couponCode: message.coupon });
    }

    // 4. OTP Forwarding
    if (message.action === 'FORWARD_OTP_TO_AMAZON' && activeTabId) {
        chrome.tabs.sendMessage(activeTabId, { action: 'PHYSICALLY_TYPE_OTP', otp: message.otp });
    }

    // 5. Trigger Webhooks
    if (message.action === 'EXECUTE_REFUND_BOT') {
        isProcessing = true; 
        routeToTab(`https://www.amazon.in/gp/your-account/order-details?orderID=${message.amazonOrderId}`);
    }
    if (message.action === 'EXECUTE_BATCH_CHECKOUT') {
        isProcessing = true; 
        routeToTab('https://www.amazon.in/cart');
    }
    if (message.action === 'EXECUTE_TRACKING_BOT') {
        isProcessing = true; 
        chrome.storage.local.set({ activeTrackingDbId: message.dbOrderId });
        routeToTab(`https://www.amazon.in/progress-tracker/package/?orderId=${message.amazonOrderId}`);
    }

    // 6. Database Callbacks (From Scrapers)
    if (message.action === 'TRACKING_SCRAPED') {
        chrome.storage.local.get(['activeTrackingDbId'], async (data) => {
            if (data.activeTrackingDbId && CONFIG.KEY) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.activeTrackingDbId}`, {
                    method: 'PATCH',
                    headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        tracking_id: message.tracking_id,
                        courier: message.courier,
                        tracking_status: message.tracking_status
                    })
                });
            }
            isProcessing = false;
        });
    }

    if (message.action === 'ITEM_CARTED') {
        chrome.storage.local.get(['currentOrderId'], async (data) => {
            if (data.currentOrderId && CONFIG.KEY) {
                await fetch(`${CONFIG.URL}/rest/v1/bulk_orders?id=eq.${data.currentOrderId}`, {
                    method: 'PATCH',
                    headers: { 'apikey': CONFIG.KEY, 'Authorization': `Bearer ${CONFIG.KEY}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        status: 'completed',
                        taxable_value: message.taxable_value || 0,
                        gst_amount: message.gst_amount || 0
                    })
                });
            }
            isProcessing = false; 
        });
    }
});